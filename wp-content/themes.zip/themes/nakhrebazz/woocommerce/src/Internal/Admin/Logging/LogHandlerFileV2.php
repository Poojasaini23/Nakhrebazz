<?php

namespace Automattic\WooCommerce\Internal\Admin\Logging;

use WC_Log_Handler_File;

/**
 * LogHandlerFileV2 class.
 */
class LogHandlerFileV2 extends WC_Log_Handler_File {}
